let store = null

export function getStore () {
    return store;
}

export function setStore (s) {
    store = s;
}
