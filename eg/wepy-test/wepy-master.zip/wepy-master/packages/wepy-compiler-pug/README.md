# wepy pug(jade) 编译器

## 安装

```
npm install wepy-compiler-pug --save-dev
```

## 配置`wepy.config.js`

```
module.exports = {
    "compilers": {
        pug: {
        }
    }
};
```

## 参数说明

[pug](https://github.com/pugjs/pug)