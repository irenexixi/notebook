let assert = require('assert');

let wepy = require('../../lib/wepy.js').default;

module.exports = class Page2 extends wepy.page {
    constructor () {
        super(1, 2, 3);
        this.methods = {
        };
        this.components = {
        };
        this.data = {
        };

        this.$props = {
        };

        this.$events = {
        };
    }
}