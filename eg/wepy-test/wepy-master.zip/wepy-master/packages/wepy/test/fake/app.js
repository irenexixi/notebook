let assert = require('assert');

let wepy = require('../../lib/wepy.js').default;

module.exports = class App extends wepy.app {

    custom () {}
}