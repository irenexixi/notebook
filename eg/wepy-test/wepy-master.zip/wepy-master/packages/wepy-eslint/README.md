# wepy eslint 检查器

## 安装

```
npm install wepy-eslint --save-dev
```

## 配置`wepy.config.js`

```
module.exports = {
	eslint: true
};
```
