# 支付宝版本

参见：[小程序框架wepy](https://github.com/wepyjs/wepy)


### 安装
```bash
wepy build --output ant
```

### Changelog
[查看CHANGELOG](https://github.com/wepyjs/wepy/blob/master/CHANGELOG.md)
