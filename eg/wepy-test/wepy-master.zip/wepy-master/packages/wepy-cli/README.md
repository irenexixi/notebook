# 小程序框架wepy命令行工具

参见：[小程序框架wepy](https://github.com/wepyjs/wepy)


### 安装
```bash
npm install wepy-cli -g
```

### Changelog
[查看CHANGELOG](https://github.com/wepyjs/wepy/blob/master/CHANGELOG.md)
